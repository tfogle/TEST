package edu.cscc;

import java.util.Scanner;
import java.lang.Math;

// Student name, date, purpose of program
public class Main {

    private static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        double time, distance, velocity;

        System.out.println("Free-fall calculator");
        System.out.print("Enter time (secs): ");
        time = input.nextDouble();
        distance = 32.0 * 0.5 * Math.pow(time,2);
        velocity = 32.0 * time;
        System.out.println("Distance: "+distance+" feet");
        System.out.println("Velocity: "+velocity+" feet/sec.");
    }
}
